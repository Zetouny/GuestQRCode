const Database = require("better-sqlite3");

const db = new Database("visitors.db");

db.exec(`
  CREATE TABLE IF NOT EXISTS visitors (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid      TEXT    NOT NULL UNIQUE,
    qr_data   TEXT    NOT NULL,
    visited_at TEXT   DEFAULT NULL,
    created_at TEXT   DEFAULT (datetime('now'))
  )
`);

module.exports = {
  /**
   * Insert a new visitor record.
   * @param {string} uuid
   * @param {string} qrData  - base64 PNG data URL
   */

  insertVisitor(uuid, qrData) {
    const stmt = db.prepare(
      `INSERT OR IGNORE INTO visitors (uuid, qr_data)
       VALUES (?, ?)`,
    );
    return stmt.run(uuid, qrData);
  },

  /** Fetch a visitor by their UUID */
  getVisitor(uuid) {
    return db.prepare("SELECT * FROM visitors WHERE uuid = ?").get(uuid);
  },

  /** Get all visitors (for the admin view) */
  getAllVisitors() {
    return db
      .prepare(
        "SELECT id, uuid, visited_at, created_at FROM visitors ORDER BY id DESC",
      )
      .all();
  },

  /** Count visitors already marked as visited */
  getVisitedCount() {
    const row = db
      .prepare("SELECT COUNT(*) AS count FROM visitors WHERE visited_at IS NOT NULL")
      .get();
    return row.count;
  },

  /** Mark a visitor as visited now */
  markVisited(uuid) {
    const stmt = db.prepare(
      "UPDATE visitors SET visited_at = datetime('now') WHERE uuid = ?",
    );
    return stmt.run(uuid);
  },
};
