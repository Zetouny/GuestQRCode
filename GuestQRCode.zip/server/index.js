const express = require("express");
const QRCode = require("qrcode");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;
const MAX_VISITS = 55;

app.use(express.static("client"));
app.use(express.json());

function generateVisitorCode() {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let index = 0; index < 6; index += 1) {
    code += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return code;
}

function getUniqueVisitorId() {
  for (let attempt = 0; attempt < 20; attempt += 1) {
    const candidate = generateVisitorCode();
    if (!db.getVisitor(candidate)) {
      return candidate;
    }
  }
  throw new Error("Unable to generate unique visitor code");
}

function extractVisitorId(scanText) {
  const text = (scanText || "").trim();
  if (!text) return null;

  const normalized = text.toUpperCase();

  const codeRegex = /^[A-Z0-9]{6}$/;
  if (codeRegex.test(normalized)) return normalized;

  return null;
}

// Main route: assign or reuse a short visitor code for this visitor
app.get("/api/qr", async (req, res) => {
  const providedId = extractVisitorId(req.query.vid);
  const visitorId = providedId || getUniqueVisitorId();

  try {
    const qrDataUrl = await QRCode.toDataURL(visitorId, {
      errorCorrectionLevel: "M",
      width: 300,
      margin: 2,
    });

    db.insertVisitor(visitorId, qrDataUrl);

    res.json({ visitorId, qr: qrDataUrl });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to generate QR code" });
  }
});

// Admin: list all visitors
app.get("/api/visitors", (req, res) => {
  res.json(db.getAllVisitors());
});

app.get("/validate", (_req, res) => {
  res.sendFile("admin.html", { root: "client" });
});

app.post("/api/visitors/register-visit", (req, res) => {
  const visitorId = extractVisitorId(req.body?.scanText);

  if (!visitorId) {
    return res.status(400).json({ error: "Invalid QR content" });
  }

  const visitor = db.getVisitor(visitorId);
  if (!visitor) {
    return res.status(404).json({ error: "Visitor not found" });
  }

  if (visitor.visited_at) {
    return res.json({
      success: true,
      visitorId: visitor.uuid,
      visitedAt: visitor.visited_at,
      alreadyVisited: true,
      maxVisits: MAX_VISITS,
      visitedCount: db.getVisitedCount(),
    });
  }

  const visitedCount = db.getVisitedCount();
  if (visitedCount >= MAX_VISITS) {
    return res.status(403).json({
      error: `Visit limit reached (${MAX_VISITS}).`,
      maxVisits: MAX_VISITS,
      visitedCount,
    });
  }

  db.markVisited(visitorId);
  const updated = db.getVisitor(visitorId);

  res.json({
    success: true,
    visitorId: updated.uuid,
    visitedAt: updated.visited_at,
    alreadyVisited: false,
    maxVisits: MAX_VISITS,
    visitedCount: visitedCount + 1,
  });
});

app.listen(PORT, () => {
  console.log(`✅ Server is running at ${PORT}`);
});
